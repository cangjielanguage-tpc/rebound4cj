import { testInstrumentParam } from '@ohos/coverage/lib/src/types/testTemplate';
export declare type queueListOpt = {
    params: testInstrumentParam;
    resolve: (value: unknown) => void;
    reject: (reason?: any) => void;
};
/**
 * 命令行生成覆盖率报告的队列中心，保证多个模块输出覆盖率的场景下可以串行输出覆盖率报告避免冲突
 */
export declare class DeviceCoverageQueueCenter {
    private queueList;
    private isExecuting;
    constructor();
    executeProxy(params: testInstrumentParam): Promise<unknown>;
    private dequeue;
    protected innerExecuteProxy(params: testInstrumentParam): Promise<void>;
}
export declare const deviceCoverageQueueCenter: DeviceCoverageQueueCenter;
